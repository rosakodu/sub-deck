"""
Subscription parser for various proxy protocols:
VLESS, VMess, Trojan, Shadowsocks, Hysteria 2.
"""

import base64
import json
import re
import ssl
import urllib.parse
import urllib.request
from typing import Dict, List, Optional, Tuple, Any

from core.constants import (
    SUBSCRIPTION_USER_AGENTS,
    SUPPORTED_SCHEMES,
    FREE_SUBSCRIPTIONS,
    FREE_SUBSCRIPTION_NODE_LIMIT,
    REGULAR_SUBSCRIPTION_NODE_LIMIT,
)
from core.pinger import select_best_nodes


def is_free_subscription(url: str) -> bool:
    """Checks whether URL belongs to pre-bundled free subscriptions."""
    if not url:
        return False
    clean_url = url.strip().lower()
    for free_url in FREE_SUBSCRIPTIONS:
        if free_url.lower() in clean_url or clean_url in free_url.lower():
            return True
    return any(marker in clean_url for marker in (
        "igareck/vpn-configs-for-russia",
        "goida-vpn-configs",
        "zieng2/wl"
    ))


def parse_endpoint(endpoint: str) -> Tuple[str, int]:
    """Parses host:port, supporting IPv6 bracket notation [::1]:port."""
    if endpoint.startswith("["):
        bracket_end = endpoint.find("]")
        if bracket_end == -1:
            return endpoint, 443
        host = endpoint[1:bracket_end]
        rest = endpoint[bracket_end + 1:]
        port = int(rest.lstrip(":")) if ":" in rest else 443
    elif ":" in endpoint:
        host, port_str = endpoint.rsplit(":", 1)
        try:
            port = int(port_str)
        except ValueError:
            port = 443
    else:
        host = endpoint
        port = 443
    return host, port


def parse_vless_link(link: str) -> Optional[Dict[str, Any]]:
    """Parses a vless:// URI into node structure."""
    parsed = urllib.parse.urlparse(link)
    netloc = parsed.netloc
    if "@" not in netloc:
        return None

    uuid, endpoint = netloc.split("@", 1)
    host, port = parse_endpoint(endpoint)
    query = urllib.parse.parse_qs(parsed.query)
    params = {k: v[0] for k, v in query.items()}
    name = urllib.parse.unquote(parsed.fragment) if parsed.fragment else f"VLESS {host}:{port}"

    extra_val = params.get("extra", "")
    extra_obj = None
    if extra_val:
        try:
            extra_obj = json.loads(urllib.parse.unquote(extra_val))
        except Exception:
            try:
                extra_obj = json.loads(extra_val)
            except Exception:
                extra_obj = None

    alpn_val = params.get("alpn", "")
    alpn_list = [a.strip() for a in alpn_val.split(",") if a.strip()] if alpn_val else []

    return {
        "type": "vless",
        "name": name,
        "server": host,
        "port": port,
        "uuid": uuid,
        "security": params.get("security", "none"),
        "sni": params.get("sni", ""),
        "pbk": params.get("pbk", ""),
        "sid": params.get("sid", ""),
        "spx": params.get("spx", ""),
        "flow": params.get("flow", ""),
        "fp": params.get("fp", "chrome"),
        "transport": params.get("type", "tcp"),
        "service_name": params.get("serviceName", ""),
        "path": params.get("path", ""),
        "host": params.get("host", ""),
        "mode": params.get("mode", ""),
        "extra": extra_obj,
        "alpn": alpn_list,
    }


def parse_vmess_link(link: str) -> Optional[Dict[str, Any]]:
    """Parses a vmess:// URI (Base64 encoded JSON)."""
    try:
        raw_b64 = link[8:].strip()
        fragment_name = ""
        if "#" in raw_b64:
            raw_b64, frag = raw_b64.split("#", 1)
            fragment_name = urllib.parse.unquote(frag.strip())
        if "?" in raw_b64:
            raw_b64 = raw_b64.split("?", 1)[0]

        b64_data = raw_b64.strip()
        padded = b64_data + "=" * (-len(b64_data) % 4)
        raw_json = base64.b64decode(padded).decode("utf-8")
        data = json.loads(raw_json)

        name = data.get("ps") or fragment_name or f"VMess {data.get('add')}:{data.get('port')}"
        tls_val = data.get("tls", "")
        security = "tls" if tls_val == "tls" else "none"

        return {
            "type": "vmess",
            "name": name,
            "server": data.get("add"),
            "port": int(data.get("port", 443)),
            "uuid": data.get("id"),
            "security": security,
            "sni": data.get("sni", ""),
            "transport": data.get("net", "tcp"),
            "path": data.get("path", "/"),
            "host": data.get("host", ""),
        }
    except Exception:
        return None


def parse_trojan_link(link: str) -> Optional[Dict[str, Any]]:
    """Parses a trojan:// URI."""
    try:
        parsed = urllib.parse.urlparse(link)
        netloc = parsed.netloc
        if "@" not in netloc:
            return None
        password, endpoint = netloc.split("@", 1)
        host, port = parse_endpoint(endpoint)
        query = urllib.parse.parse_qs(parsed.query)
        params = {k: v[0] for k, v in query.items()}
        name = urllib.parse.unquote(parsed.fragment) if parsed.fragment else f"Trojan {host}:{port}"

        return {
            "type": "trojan",
            "name": name,
            "server": host,
            "port": port,
            "password": password,
            "security": "tls",
            "sni": params.get("sni", ""),
            "transport": params.get("type", "tcp"),
            "service_name": params.get("serviceName", ""),
            "path": params.get("path", ""),
            "host": params.get("host", ""),
        }
    except Exception:
        return None


def parse_ss_link(link: str) -> Optional[Dict[str, Any]]:
    """Parses a ss:// (Shadowsocks) URI."""
    try:
        parsed = urllib.parse.urlparse(link)
        netloc = parsed.netloc

        if "@" not in netloc:
            try:
                padded = netloc + "=" * (-len(netloc) % 4)
                decoded = base64.b64decode(padded).decode("utf-8")
                if "@" in decoded:
                    netloc = decoded
            except Exception:
                pass

        if "@" not in netloc:
            return None

        credentials, endpoint = netloc.split("@", 1)
        if ":" not in credentials:
            try:
                padded = credentials + "=" * (-len(credentials) % 4)
                credentials = base64.b64decode(padded).decode("utf-8")
            except Exception:
                pass

        if ":" not in credentials:
            return None

        method, password = credentials.split(":", 1)
        host, port = parse_endpoint(endpoint)
        name = urllib.parse.unquote(parsed.fragment) if parsed.fragment else f"Shadowsocks {host}:{port}"

        return {
            "type": "shadowsocks",
            "name": name,
            "server": host,
            "port": port,
            "method": method,
            "password": password,
            "security": "none",
        }
    except Exception:
        return None


def parse_hysteria2_link(link: str) -> Optional[Dict[str, Any]]:
    """Parses a hysteria2:// or hy2:// URI."""
    try:
        parsed = urllib.parse.urlparse(link)
        netloc = parsed.netloc
        if "@" not in netloc:
            return None
        password, endpoint = netloc.split("@", 1)
        host, port = parse_endpoint(endpoint)
        query = urllib.parse.parse_qs(parsed.query)
        params = {k: v[0] for k, v in query.items()}
        name = urllib.parse.unquote(parsed.fragment) if parsed.fragment else f"Hysteria2 {host}:{port}"

        insecure = params.get("insecure", "0") in ("1", "true")

        return {
            "type": "hysteria2",
            "name": name,
            "server": host,
            "port": port,
            "password": password,
            "security": "tls",
            "sni": params.get("sni", ""),
            "insecure": insecure,
            "obfs_type": params.get("obfs", ""),
            "obfs_password": params.get("obfs-password", ""),
        }
    except Exception:
        return None


def parse_clash_proxy(proxy: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Converts a Clash/Mihomo YAML proxy dict into sub-deck internal node structure."""
    if not isinstance(proxy, dict):
        return None

    proto = str(proxy.get("type", "")).lower()
    name = str(proxy.get("name", "Proxy"))
    server = str(proxy.get("server", ""))
    port = int(proxy.get("port", 443))

    if not server or not port:
        return None

    if proto == "vless":
        uuid = str(proxy.get("uuid", ""))
        network = str(proxy.get("network", "tcp")).lower()
        tls = bool(proxy.get("tls", False))
        flow = str(proxy.get("flow", ""))
        reality_opts = proxy.get("reality-opts") or {}

        security = "none"
        pbk = ""
        sid = ""
        spx = ""
        if reality_opts:
            security = "reality"
            pbk = str(reality_opts.get("public-key", ""))
            sid = str(reality_opts.get("short-id", ""))
            spx = str(reality_opts.get("spider-x", ""))
        elif tls:
            security = "tls"

        sni = str(proxy.get("servername") or proxy.get("sni") or "")
        fp = str(proxy.get("client-fingerprint", "chrome"))

        grpc_opts = proxy.get("grpc-opts") or {}
        service_name = str(grpc_opts.get("grpc-service-name", ""))

        ws_opts = proxy.get("ws-opts") or {}
        ws_path = str(ws_opts.get("path", "/"))
        ws_headers = ws_opts.get("headers") or {}
        ws_host = str(ws_headers.get("Host", ""))

        return {
            "type": "vless",
            "name": name,
            "server": server,
            "port": port,
            "uuid": uuid,
            "security": security,
            "sni": sni,
            "pbk": pbk,
            "sid": sid,
            "spx": spx,
            "flow": flow,
            "fp": fp,
            "transport": network,
            "service_name": service_name,
            "path": ws_path,
            "host": ws_host,
        }

    elif proto == "vmess":
        uuid = str(proxy.get("uuid", ""))
        network = str(proxy.get("network", "tcp")).lower()
        tls = bool(proxy.get("tls", False))
        sni = str(proxy.get("servername") or proxy.get("sni") or "")
        ws_opts = proxy.get("ws-opts") or {}
        path = str(ws_opts.get("path", "/"))
        ws_headers = ws_opts.get("headers") or {}
        host = str(ws_headers.get("Host", ""))

        return {
            "type": "vmess",
            "name": name,
            "server": server,
            "port": port,
            "uuid": uuid,
            "security": "tls" if tls else "none",
            "sni": sni,
            "transport": network,
            "path": path,
            "host": host,
        }

    elif proto == "trojan":
        password = str(proxy.get("password", ""))
        sni = str(proxy.get("sni") or proxy.get("servername") or "")
        return {
            "type": "trojan",
            "name": name,
            "server": server,
            "port": port,
            "password": password,
            "security": "tls",
            "sni": sni,
        }

    elif proto in ("ss", "shadowsocks"):
        cipher = str(proxy.get("cipher", ""))
        password = str(proxy.get("password", ""))
        return {
            "type": "shadowsocks",
            "name": name,
            "server": server,
            "port": port,
            "method": cipher,
            "password": password,
            "security": "none",
        }

    elif proto in ("hysteria2", "hy2"):
        password = str(proxy.get("password", ""))
        sni = str(proxy.get("sni") or "")
        insecure = bool(proxy.get("skip-cert-verify", False))
        obfs_opts = proxy.get("obfs") or ""
        obfs_pass = proxy.get("obfs-password") or ""
        return {
            "type": "hysteria2",
            "name": name,
            "server": server,
            "port": port,
            "password": password,
            "security": "tls",
            "sni": sni,
            "insecure": insecure,
            "obfs_type": obfs_opts,
            "obfs_password": obfs_pass,
        }

    return None


def parse_clash_yaml_nodes(content: bytes) -> List[Dict[str, Any]]:
    """Extracts proxies from Clash / Mihomo YAML payload."""
    try:
        import yaml
        data = yaml.safe_load(content)
        if isinstance(data, dict):
            proxies = data.get("proxies", [])
            if isinstance(proxies, list):
                nodes = []
                for p in proxies:
                    parsed = parse_clash_proxy(p)
                    if parsed:
                        nodes.append(parsed)
                return nodes
    except Exception:
        pass
    return []


def parse_node_link(link: str) -> Optional[Dict[str, Any]]:
    """Dispatches line to appropriate protocol parser."""
    line = link.strip()
    if line.startswith("vless://"):
        return parse_vless_link(line)
    if line.startswith("vmess://"):
        return parse_vmess_link(line)
    if line.startswith("trojan://"):
        return parse_trojan_link(line)
    if line.startswith("ss://"):
        return parse_ss_link(line)
    if line.startswith("hysteria2://") or line.startswith("hy2://"):
        return parse_hysteria2_link(line)
    return None


def download_subscription_payload(url: str, timeout: float = 15.0) -> Tuple[Optional[bytes], Optional[Any]]:
    """Downloads subscription raw bytes using fallback User-Agents."""
    ctx = ssl._create_unverified_context()
    for ua in SUBSCRIPTION_USER_AGENTS:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": ua})
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                return resp.read(), resp.info()
        except Exception:
            continue
    return None, None


def parse_subscription_userinfo(headers: Any) -> Dict[str, int]:
    """Parses subscription-userinfo header: upload, download, total, expire (in bytes/epoch)."""
    userinfo: Dict[str, int] = {}
    if not headers:
        return userinfo

    raw_header = None
    for k, v in headers.items():
        if k.lower() == "subscription-userinfo":
            raw_header = v
            break

    if not raw_header:
        return userinfo

    # Typical format: upload=1073741824; download=5368709120; total=53687091200; expire=1735689600
    for part in raw_header.split(";"):
        part = part.strip()
        if "=" in part:
            key, val = part.split("=", 1)
            key = key.strip().lower()
            val = val.strip()
            try:
                if key in ("upload", "download", "total", "expire"):
                    userinfo[key] = int(val)
            except ValueError:
                continue

    return userinfo


def parse_content_disposition_filename(headers: Any) -> Optional[str]:
    """Extracts subscription filename/title from Content-Disposition header."""
    if not headers:
        return None

    raw_header = None
    for k, v in headers.items():
        if k.lower() == "content-disposition":
            raw_header = v
            break

    if not raw_header:
        return None

    # Try RFC 5987 filename*=UTF-8''...
    match_rfc = re.search(r"filename\*\s*=\s*(?:UTF-8''|utf-8'')([^;\s]+)", raw_header, re.IGNORECASE)
    if match_rfc:
        try:
            return urllib.parse.unquote(match_rfc.group(1)).strip().strip('"\'')
        except Exception:
            pass

    # Try filename="abc" or filename=abc
    match = re.search(r'filename\s*=\s*("([^"]+)"|([^;\s]+))', raw_header, re.IGNORECASE)
    if match:
        name = match.group(2) if match.group(2) is not None else match.group(3)
        if name:
            name = name.strip().strip('"\'')
            # Decode if percent-encoded
            try:
                name = urllib.parse.unquote(name)
            except Exception:
                pass
            return name

    return None


def extract_update_interval(headers: Any, text: str) -> Optional[int]:
    """Finds profile-update-interval from HTTP headers or payload text."""
    if headers:
        for key, val in headers.items():
            if key.lower() == "profile-update-interval":
                try:
                    return int(val)
                except Exception:
                    pass

    match = re.search(r'(?:#|//)?\s*profile-update-interval\s*:\s*(\d+)', text[:1000], re.IGNORECASE)
    if match:
        try:
            return int(match.group(1))
        except Exception:
            pass
    return None


def decode_subscription_lines(content: bytes) -> List[str]:
    """Decodes plain text or base64 subscription payload into lines."""
    try:
        text = content.decode("utf-8").strip()
    except Exception:
        text = content.decode("latin-1", errors="replace").strip()

    is_plain = any(text.startswith(sch) or f"\n{sch}" in text for sch in SUPPORTED_SCHEMES)
    if is_plain:
        return text.splitlines()

    # Attempt base64 decoding
    try:
        clean_b64 = "".join(text.split())
        padded = clean_b64 + "=" * (-len(clean_b64) % 4)
        decoded = base64.b64decode(padded).decode("utf-8", errors="replace")
        return decoded.splitlines()
    except Exception:
        return text.splitlines()


def parse_subscription_nodes(url: str, log_func=None) -> Tuple[List[Dict[str, Any]], Optional[int], Dict[str, Any]]:
    """Fetches, parses and dedupes nodes for a subscription URL, returning (nodes, interval, metadata)."""
    content, headers = download_subscription_payload(url)
    if content is None:
        if log_func:
            log_func(f"Failed to download subscription content for: {url}")
        return [], None, {}

    try:
        raw_text = content.decode("utf-8", errors="ignore")
    except Exception:
        raw_text = ""
    interval = extract_update_interval(headers, raw_text)

    metadata: Dict[str, Any] = {}
    userinfo = parse_subscription_userinfo(headers)
    if userinfo:
        metadata.update(userinfo)

    filename = parse_content_disposition_filename(headers)
    if filename:
        metadata["name"] = filename

    # Check if subscription is a Clash / Mihomo YAML payload
    yaml_nodes = parse_clash_yaml_nodes(content)
    raw_nodes = []
    if yaml_nodes:
        for node in yaml_nodes:
            node["subscription_url"] = url
            raw_nodes.append(node)
    else:
        lines = decode_subscription_lines(content)
        for line in lines:
            node = parse_node_link(line)
            if node:
                node["subscription_url"] = url
                raw_nodes.append(node)

    # Deduplicate nodes by (name, server, port)
    seen_names = set()
    seen_endpoints = set()
    unique_nodes = []
    for node in raw_nodes:
        name = node.get("name")
        endpoint = (node.get("server"), node.get("port"))
        if name and endpoint[0] and endpoint[1]:
            if name not in seen_names and endpoint not in seen_endpoints:
                seen_names.add(name)
                seen_endpoints.add(endpoint)
                unique_nodes.append(node)

    if log_func:
        log_func(f"Parsed {len(unique_nodes)} unique nodes for {url}")

    # Select responsive nodes
    limit = FREE_SUBSCRIPTION_NODE_LIMIT if is_free_subscription(url) else REGULAR_SUBSCRIPTION_NODE_LIMIT
    selected_nodes = select_best_nodes(unique_nodes, target_count=limit, log_func=log_func)

    return selected_nodes, interval, metadata
